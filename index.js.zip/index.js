//This is still work in progress
/*
Please report any bugs to nicomwaks@gmail.com
i have added console.log on line 48
 */
'use strict'

const express = require('express')
const bodyParser = require('body-parser')
const request = require('request')
const app = express()

app.set('port', (process.env.PORT || 5000))

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({extended: false}))

// parse application/json
app.use(bodyParser.json())

// index
app.get('/', function (req, res) {
	res.send('hello world i am a secret bot')
})

// for facebook verification
app.get('/webhook/', function (req, res) {
	if (req.query['hub.verify_token'] === 'flamelion') {
		{
      res.send(req.query['hub.challenge'])
  }
	} else {
		res.send('Error, wrong token')
	}

})

// to post data
app.post('/webhook/', function (req, res) {
 var data = req.body;
 if (data.object == 'page') {
   menuButton();}
	let messaging_events = req.body.entry[0].messaging
	for (let i = 0; i < messaging_events.length; i++) {
		let event = req.body.entry[0].messaging[i]
		let sender = event.sender.id
	//	if (event.message && event.message.text) {
	//		let text = event.message.text

			//sendTextMessage(sender, "Text received, echo: " + text.substring(0, 200))
	//	}
		if (event.postback) {
			let text = JSON.stringify(event.postback)
      if(text==='payload_name')
			   sendTextMessage(sender, "You are in the Flamelion system ", token)
        else if(text==='payload_led_on')
        { //call_url("http://flamelion.herukuapp.com?updateled=on")
					sendTextMessage(sender,  'Your led is on', token)
				}
				 else if(text==='payload_led_off')
				 {//call_url("http://flamelion.herukuapp.com?updateled=off")
					sendTextMessage(sender,  'Your led is off', token)
				 }
					else if(text==='payload_led_status')
					{
						//var js=request_json("http://flamelion.herukuapp.com/ledstaus")
						// var status=js.param("led_status");
					 sendTextMessage(sender,  'Your led is status', token)
				 	}
			continue
		}
	}
	res.sendStatus(200)
})


// recommended to inject access tokens as environmental variables, e.g.
// const token = process.env.FB_PAGE_ACCESS_TOKEN
const token = "EAAZA9Eld9BZBUBANa1saoOs16JUiBZB2sdZBZAOCUUIpgYNWZAd8Pn0lk4TByzDZBmJSZBOVlNkGocP9YGQnVPyqFb7GqSVTNATrZCc2tlSHNkXJiFokAweqncZCn2DaVAYklXAOCAEWPgwtQsk2tjfjxxorZAgfMZAmm4D5qhCPW78DhwZDZD"

function sendTextMessage(sender, text) {
	let messageData = { text:text }

	request({
		url: 'https://graph.facebook.com/v2.6/me/messages',
		qs: {access_token:token},
		method: 'POST',
		json: {
			recipient: {id:sender},
			message: messageData,
		}
	}, function(error, response, body) {
		if (error) {
			console.log('Error sending messages: ', error)
		} else if (response.body.error) {
			console.log('Error: ', response.body.error)
		}
	})
}

function menuButton()  {
	let   call_to_actions ={
    "setting_type" : "call_to_actions",
    "thread_state" : "existing_thread",
      "call_to_actions":[{
        "type":"postback",
        "title":"System Name",
        "payload":"payload_name"
      },
      {
        "type":"postback",
        "title":"Led On",
        "payload":"payload_led_on"
      },
      {
        "type":"postback",
        "title":"Led Off",
        "payload":"payload_led_off"
      },
      {
        "type":"postback",
        "title":"Led Status",
        "payload":"payload_led_status"
      },
      {
        "type":"web_url",
        "title":"Powered by Nyan Naing Tun",
        "url":"http://www.goldenhussargroup.com/"
      }
    ]
    }

	request({
		url: 'https://graph.facebook.com/v2.6/me/thread_settings',
		qs: {access_token:token},
		method: 'POST',
		json: call_to_actions,
	}, function(error, response, body) {
    if (!error && response.statusCode == 200) {
    var recipientId = body.recipient_id;
    var messageId = body.message_id;

    console.log("Successfully sent generic message with id %s to recipient %s",
      messageId, recipientId);
  }
		else if (error) {
			console.log('Error sending messages: ', error)
		} else if (response.body.error) {
			console.log('Error: ', response.body.error)
		}
	})

}



// spin spin sugar
app.listen(app.get('port'), function() {
	console.log('running on port', app.get('port'))
})
